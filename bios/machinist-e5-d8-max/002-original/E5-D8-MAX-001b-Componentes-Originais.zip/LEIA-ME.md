# Componentes originais da BIOS 001b

Extraídos sem alterações do backup de 16 MiB que passou nas verificações descritas na conversa. Não foi atualizado microcódigo, apagada NVRAM nem limpo SPS. Os offsets do manifesto são absolutos no chip SPI.

## Arquivos

| Parte | Offset SPI | Tamanho |
| --- | --- | --- |
| Descriptor original | 0x000000–0x000FFF | 4.096 bytes |
| SPS original completo | 0x001000–0x7FFFFF | 8.384.512 bytes |
| Dois volumes NVRAM originais | 0x800000–0x87FFFF | 524.288 bytes |
| Volume de inicialização BootFV original | 0xDA0000–0xFFFFFF | 2.490.368 bytes |

A pasta Inicializacao contém também 11 arquivos FFS SEC/PEI identificados como CpuPei, CpuMpPei, CpuIoPei, CpuPeiDummy, UncoreInitPeim, PlatformEarlyInit, PlatformInfo, IioDmiInitPeim, PchInitPeim, PeiCore e Volume Top File, além de seis FFS DXE de apoio: CpuMpDxe, CpuArchDxe, PlatformCpuPolicy, SaveMemoryConfig, MemorySubClass e CpuCsrAccess.

Os FFS são cópias completas dos arquivos armazenados na ROM, incluindo cabeçalhos e seções, e não apenas executáveis descomprimidos. Foram conferidos GUID, tamanho, checksum de cabeçalho e CRC do inventário UEFIExtract. Todo BIN/FFS exportado foi comparado byte a byte com sua fatia da fonte e tem SHA-256 no manifesto.

## Limites da separação

A inicialização de CPU e memória não é um único arquivo independente. Não foi identificado e validado um MRC autônomo nem provado que a seleção de FFS contém todo o código relacionado a memória/CPU. Por isso foi incluído também o BootFV inteiro, com os demais módulos e dados nele presentes. Esse volume não contém necessariamente todas as dependências, políticas e tabelas que ficam em outros volumes. A seleção por nome não é uma análise completa do fluxo de inicialização ou de suas dependências.

Este pacote serve para preservação e análise. Não é uma imagem completa para gravação e não deve ser concatenado como se fosse uma ROM completa. Os módulos compartilham conteúdo com o BootFV; há sobreposição intencional entre esses arquivos. Não está demonstrado que possam ser transplantados para a BIOS 006 ou outra placa, nem que um transplante preserve o funcionamento com dois v4. NVRAM e SPS contêm dados específicos desta placa; manter estes arquivos privados.

A validação anterior encontrou BUP do SPS com hash correto, UEFI sem erros detectados de checksum/descompressão e código idêntico às leituras de 8 MiB. Isso não autentica ou verifica todos os componentes do SPS. Ainda é recomendada segunda leitura completa independente para confirmar repetibilidade.
