# Sua BIOS 002 com logo Covenant — candidata experimental

Troca somente do logo na BIOS `X99D8 Ver:002 12/20/2022 09:47:26`, usando o backup `001b_ORIGINAL.rom` fornecido pelo proprietário. Nenhum componente veio da BIOS 006.

## Arquivos de firmware

- `E5-D8-MAX-002-LOGO-COVENANT-EXPERIMENTAL-SPI-16MiB.bin`: imagem SPI completa de 16.777.216 bytes, incluindo Descriptor e SPS originais.
- `E5-D8-MAX-002-LOGO-COVENANT-EXPERIMENTAL-BIOS-8MiB.bin`: somente a região BIOS de 8.388.608 bytes, exatamente a metade superior da imagem SPI.

Esses formatos têm usos diferentes. Não gravar o arquivo de 8 MiB como imagem completa do chip de 16 MiB, nem enviar o de 16 MiB para uma operação que espera somente a região BIOS. Este pacote não executa gravações.

## Arte utilizada

Imagem recebida em `logo-covenant-machctrl-logo-xeon.7z`. O arquivo interno tem extensão PNG, mas o conteúdo é JPEG RGB de 2752 × 1536 pixels; foi reconhecido pelo conteúdo. A conversão produziu BMP RGB de 24 bits, sem compressão interna, com 568 × 317 pixels. A largura acompanha a do logo original; a altura resulta da preservação da proporção. Não houve corte, geração de arte nova, alteração de textos ou efeitos adicionais. A prévia PNG mostra os mesmos pixels do BMP inserido.

## Substituição na estrutura UEFI

O BMP foi colocado na seção RAW do FFS com GUID `7BB28B99-61BB-11D5-9A5D-0090273FC14D`, mantendo a seção UI Logo.bmp e o formato GUID-defined LZMA da base. A arte ocupa mais espaço que o logo original. Para preservar todos os demais módulos nos mesmos endereços, o slot antigo foi substituído por um FFS PAD vazio e o novo FFS do logo foi colocado em espaço FF livre confirmado no mesmo volume. Os cabeçalhos e checksums afetados foram ajustados.

Por isso o inventário passa de 309 para 310 FFS: há uma entrada PAD adicional, sem driver novo. Restam 1737976 bytes livres no volume principal.

## Verificações concluídas

- Descriptor, SPS e dois volumes NVRAM preservados byte a byte.
- FIT e volume de inicialização completos preservados byte a byte.
- Outros 308 FFS com endereços, tamanhos, CRC e conteúdo idênticos à base.
- Todos os microcódigos preservados. Xeon v4 permanece em **0B000038**, e o 306F2 em **3D**. Esta variante NÃO inclui a atualização 49/040 preparada anteriormente.
- UEFIExtract NE A75 analisou e descomprimiu a candidata sem novos erros. Permanecem apenas os avisos anteriores: ACM não interpretado e identificador JEDEC da tabela VSCC não reconhecido, além da informação sobre localização FIT.
- Logo extraído novamente da candidata pelo UEFIExtract: BMP idêntico byte a byte ao preparado, decodificado também com um segundo leitor.
- Hash BUP do SPS permanece correspondente ao manifesto; isso não valida todos os módulos do SPS.
- Arquivo de 8 MiB comparado com a fatia BIOS do arquivo de 16 MiB; conteúdo idêntico.

## Limites

**EXPERIMENTAL: não houve teste de boot, exibição do logo na placa, validação de assinaturas nem gravação física.** Verificação estrutural não garante inicialização ou exibição. A apresentação depende das opções de logo da BIOS e do modo gráfico disponível. Guardar o backup original intacto e confirmar outra leitura completa independente antes de testar a candidata continua sendo recomendado.

A versão 0.2 do Convenant BIOS Tools usa uma lista restrita de fingerprints de firmware; esta variante com logo altera o fingerprint e não faz parte dos perfis de gravação liberados daquela versão. Não é necessário nem indicado contornar suas verificações.

As imagens contêm NVRAM e SPS próprios da unidade de origem. Não são BIOS universais para outras placas vendidas com o mesmo nome.
