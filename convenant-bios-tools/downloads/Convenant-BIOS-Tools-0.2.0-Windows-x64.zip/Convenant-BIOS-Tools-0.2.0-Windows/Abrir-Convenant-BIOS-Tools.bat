@echo off
start "" "%~dp0Convenant-BIOS-Tools.exe"
