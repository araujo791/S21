# Qt 6.8.3 — bibliotecas compartilhadas

Este aplicativo utiliza PySide6 Essentials/Shiboken 6.8.3 e bibliotecas Qt compartilhadas. As bibliotecas continuam separadas dos fontes do aplicativo e podem ser substituídas por versões compatíveis.

Textos LGPL-3.0 e GPL-3.0 estão nesta pasta. Código-fonte correspondente do Qt: https://code.qt.io/cgit/qt/ e https://download.qt.io/archive/qt/6.8/6.8.3/ . PySide/Shiboken: https://code.qt.io/cgit/pyside/pyside-setup.git/tag/?h=v6.8.3 .

Os fontes Python/C deste aplicativo estão no próprio pacote. O código do aplicativo não foi ligado estaticamente às bibliotecas Qt. O Python possui licença própria incluída.
